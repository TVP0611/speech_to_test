[VNESEcorpust.txt](http://viet.jnlp.org/download-du-lieu-tu-vung-corpus)

[trainingdata.tar.gz](http://sourceforge.net/projects/jvnsegmenter/files/jvnsegmenter/JVnSegmenter/trainingdata.tar.gz/download)
