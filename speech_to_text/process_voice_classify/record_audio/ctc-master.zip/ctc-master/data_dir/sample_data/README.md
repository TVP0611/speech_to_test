LibriSpeech samples
------
Samples from the LibriSpeech dataset, from the dev-clean dataset.
